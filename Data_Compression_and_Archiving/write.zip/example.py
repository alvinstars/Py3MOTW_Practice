#demopkg2/overloaded.py

def func():
    print('This is the dev version of shallow func().')
