README

def func():
    print('This is the dev version of shallow func().')
